
# Earthquake Forecasting Project

Time-series analysis and forecasting of earthquake activity.

## Models
- ARIMA
- SARIMA
- RNN
- LSTM
- Prophet

## Technologies
Python, Pandas, NumPy, Matplotlib, Statsmodels,
Scikit-learn, TensorFlow, Google Colab

## Dataset
Earthquake data collected from USGS.

## Evaluation
MAE, MSE, RMSE
